# Description

Manages DVD drives attached to a Hyper-V virtual machine.

## Requirements

* The Hyper-V Role has to be installed on the machine.
* The Hyper-V PowerShell module has to be installed on the machine.
