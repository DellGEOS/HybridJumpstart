# Description

Manages VMs in a Hyper-V host.

The following properties **cannot** be changed after VM creation:

* VhdPath
* Path
* Generation

## Requirements

* The Hyper-V Role has to be installed on the machine.
* The Hyper-V PowerShell module has to be installed on the machine.
